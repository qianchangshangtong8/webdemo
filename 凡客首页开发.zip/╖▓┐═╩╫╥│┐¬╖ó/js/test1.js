function clearfield1(){
if (document.search1.search2.value == "搜“卡其裤”，体验与众不同")
document.search1.search2.value = "";
}